/**
 * form.js
 * Handles quote form submission without opening Gmail/Outlook.
 *
 * Uses FormSubmit.co so this GitHub Pages site can send the request
 * to the Rocket Rebar Service email address without a mailto: popup.
 *
 * IMPORTANT:
 * The first successful submission to this address may require
 * email activation/confirmation from FormSubmit.co.
 *
 * Rocket Rebar Service
 */

'use strict';

function initForm() {
  const form = document.getElementById('quote-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const button = form.querySelector('button[type="submit"], input[type="submit"]');
    const originalText = button ? button.textContent : '';

    if (button) {
      button.disabled = true;
      button.textContent = 'SENDING...';
    }

    const data = new FormData(form);
    const name = data.get('name') || '';
    const company = data.get('company') || '';
    const email = data.get('email') || '';
    const phone = data.get('phone') || '';
    const service = data.get('service') || '';
    const details = data.get('details') || '';

    const payload = new FormData();
    payload.append('_subject', `New Rebar Quote Request – ${name}${company ? ` (${company})` : ''}`);
    payload.append('_template', 'table');
    payload.append('_captcha', 'false');
    payload.append('Name', name);
    payload.append('Company', company);
    payload.append('Email', email);
    payload.append('Phone', phone);
    payload.append('Service', service);
    payload.append('Project Details', details);

    try {
      const response = await fetch(
        'https://formsubmit.co/ajax/Rocketrebarservice@outlook.com',
        {
          method: 'POST',
          body: payload,
          headers: {
            'Accept': 'application/json'
          }
        }
      );

      const result = await response.json();

      if (!response.ok || result.success !== 'true') {
        throw new Error(result.message || 'Unable to send request.');
      }

      alert('Thank you! Your quote request has been sent successfully.');
      form.reset();
    } catch (error) {
      console.error('Quote form error:', error);
      alert(
        'Sorry, your request could not be sent right now. ' +
        'Please try again or contact us directly by email.'
      );
    } finally {
      if (button) {
        button.disabled = false;
        button.textContent = originalText;
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', initForm);
